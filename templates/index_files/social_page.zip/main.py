from __init__ import *
from functions import *



#Files
@app.route('/favicon.ico')
def favicon():  return url_for('static', filename='favicon.ico')




#pages

@app.errorhandler(404)
def page_not_found(e):
	# note that we set the 404 status explicitly
	return render_template('404.html'), 404

@app.errorhandler(403)
def page_access_denied(e):
	# note that we set the 404 status explicitly
	return render_template('403.html'), 403

@app.route('/', methods=['GET', 'POST'])
def index():
	hash_ = request.cookies.get('hash')
	user = get_by_hash(hash_,users)
	if user == False:
		return redirect('login')
	return make_response(render_template('index.html',username=user,phone=users[user]['phone'],fio=users[user]['fio']))

	
@app.route('/logout', methods=['GET', 'POST'])
def logout():
	response = make_response(redirect(url_for('login')))
	response.set_cookie('my_cookie', '', expires=datetime.now() - timedelta(days=1))
	return response

@app.route('/edit', methods=['GET', 'POST'])
def edit_index():
	hash_ = request.cookies.get('hash')
	user = get_by_hash(hash_,users)
	if user == False:
		return redirect('login')

	if request.method == 'POST':
		phone = request.form['phone']
		fi = request.form['first_name'].strip()
		ii = request.form['last_name'].strip()
		oi = request.form['patronymic'].strip()
		snils = request.form['snils']
		passport_series = request.form['passport_series']
		birthdate = request.form['birthdate']
		citizenship = request.form['citizenship']
		fio = fi+' '+ii+' '+oi
		users[user]['snils'] = snils
		users[user]['passport_series'] = passport_series
		users[user]['birthdate'] = birthdate
		users[user]['citizenship'] = citizenship
		users[user]['phone'] = phone
		if fio != users[user]['fio']:
			users[user]['fio'] = fio

	return make_response(render_template('edit_index.html',
		username=user,phone=users[user]['phone'],
		fi=users[user]['fio'].split(' ')[0],
		ii=users[user]['fio'].split(' ')[1],
		oi=users[user]['fio'].split(' ')[2],
		snils=users[user]['snils'],
		passport_series=users[user]['passport_series'],
		birthdate=users[user]['birthdate'],
		citizenship=users[user]['citizenship']))

@app.route('/index_files/<path:path>')
def index_files(path):
	return send_from_directory('templates/index_files/', path)

@app.route('/edit_index_files/<path:path>')
def edit_index_files(path):
	return send_from_directory('templates/index_files/', path)

@app.route('/register', methods=['GET', 'POST'])
def register():
	global username
	if request.method == 'POST':
		username = request.form['username']
		if username == 'None':
			return render_template('registration.html', message='Username already exists')
		password = request.form['password']
		phone = request.form['phone']
		fio = request.form['fio']
		if username not in users:
			users[username] = {'password': password,'phone':phone,'fio':fio, 'hash': generate_hash(),'snils':'','passport_series':'', 'birthdate':'','citizenship':''}
			resp = make_response(render_template('registration.html', message='Registration successful'))
			resp.set_cookie('hash', users[username]['hash'])
			return resp
		else:
			return render_template('registration.html', message='Username already exists')
	else:
		return render_template('registration.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
	global username

	if request.method == 'POST':
		username = request.form['username']
		password = request.form['password']
		if username in users and password == users[username]['password']:
			resp = make_response(render_template('login.html', message='<script>window.location.href = "/";</script>'))
			resp.set_cookie('hash', users[username]['hash'])
			return resp
		else:
			return render_template('login.html', message='Invalid username or password')
	else:
		response = make_response(render_template('login.html'))
		response.set_cookie('my_cookie', '', expires=datetime.now() - timedelta(days=1))
		return render_template('login.html')