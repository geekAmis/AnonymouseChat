from main import *

socketio.run(app, host=f'{host}', port=80)
